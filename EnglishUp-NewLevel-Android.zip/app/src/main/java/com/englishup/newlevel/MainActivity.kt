package com.englishup.newlevel

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Bg = Color(0xFF0D1018)
private val Panel = Color(0xFF191F2D)
private val Purple = Color(0xFF8B7CFF)
private val Muted = Color(0xFFAAB1C4)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { EnglishUpApp(onSpeak = { speak(it) }) }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "englishup") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun EnglishUpApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("englishup_progress", 0) }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var done by remember { mutableStateOf(prefs.getStringSet("done", emptySet())?.toSet() ?: emptySet()) }
    var page by remember { mutableStateOf("Home") }
    var answer by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf("") }
    var typed by remember { mutableStateOf("") }
    var recognized by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }

    fun award(id: String, points: Int = 20) {
        if (!done.contains(id)) {
            done = done + id
            xp += points
            prefs.edit().putInt("xp", xp).putStringSet("done", done).apply()
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeechRecognition(context) { recognized = it; typed = it; listening = false }
        else { listening = false; feedback = "Microphone permission is needed for speaking practice." }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, secondary = Color(0xFFB9AEFF), background = Bg,
        surface = Panel, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Home", "Learn", "Listen", "Speak", "Words", "Progress").forEach { item ->
                        val icon = when(item) {
                            "Home" -> Icons.Default.Home
                            "Learn" -> Icons.Default.School
                            "Listen" -> Icons.Default.Headphones
                            "Speak" -> Icons.Default.Mic
                            "Words" -> Icons.Default.MenuBook
                            else -> Icons.Default.Insights
                        }
                        NavigationBarItem(
                            selected = page == item, onClick = { page = item; answer = ""; feedback = "" },
                            icon = { Icon(icon, contentDescription = item) },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White, selectedTextColor = Purple,
                                indicatorColor = Color(0xFF38315F), unselectedIconColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(shape = RoundedCornerShape(14.dp), color = Purple) {
                        Icon(Icons.Default.School, null, Modifier.padding(10.dp), tint = Color.White)
                    }
                    Column {
                        Text("EnglishUp", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("NEW LEVEL · ENGLISH LEARNING", color = Muted, fontSize = 10.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Text("A1", color = Purple, fontWeight = FontWeight.Bold)
                }

                when (page) {
                    "Home" -> {
                        CardBlock {
                            Text("WELCOME BACK", color = Muted, fontSize = 11.sp)
                            Text("Hello, Gustavo! 👋", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("Your next level starts here.", color = Muted)
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Stat("XP", xp.toString())
                                Stat("MISSIONS", "${done.size}/3")
                                Stat("LEVEL", "A1")
                            }
                        }
                        Text("Your daily mission", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("30 minutes · 10 minutes per skill · Earn 60 XP", color = Muted)
                        val missions = listOf(
                            Triple("listen", "Listening", "Listen, understand and identify everyday English."),
                            Triple("speak", "Speaking", "Say or write your own English sentences."),
                            Triple("words", "Vocabulary", "Learn useful phrases and review them.")
                        )
                        missions.forEach { (id, title, desc) ->
                            CardBlock {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                        Text(desc, color = Muted, fontSize = 12.sp)
                                    }
                                    if (done.contains(id)) Text("DONE ✓", color = Color(0xFF76D9A0))
                                    else Button(onClick = { page = when(id) { "listen" -> "Listen"; "speak" -> "Speak"; else -> "Words" } }) { Text("Start") }
                                }
                            }
                        }
                    }
                    "Learn" -> {
                        Header("Lesson 01 — Present Simple", "Talk about routines, hobbies and facts.")
                        CardBlock {
                            Example("I train calisthenics.", "Eu treino calistenia.", onSpeak)
                            Example("I play video games.", "Eu jogo videogames.", onSpeak)
                            Example("I usually listen to music.", "Eu geralmente escuto música.", onSpeak)
                        }
                        Quiz(
                            question = "Choose the correct sentence:",
                            options = listOf("I usually training.", "I usually train.", "I usually trains."),
                            correct = 1, answer = answer, onAnswer = { answer = it; feedback = "" },
                            feedback = feedback, onCheck = { selected ->
                                feedback = if (selected == 1) { award("lesson01", 10); "Correct! With I, use the base verb: I train, I play, I listen." }
                                else "Not quite. Remember: I usually + base verb. The answer is 'I usually train.'"
                            }
                        )
                        Button(onClick = { award("lesson01done"); page = "Home" }, modifier = Modifier.fillMaxWidth()) { Text("Complete lesson (+20 XP)") }
                    }
                    "Listen" -> {
                        Header("Listening practice", "Use the speaker button to hear natural English pronunciation.")
                        CardBlock {
                            Text("Today's phrase", color = Purple, fontWeight = FontWeight.Bold)
                            Text("I usually work out in the afternoon.", fontSize = 20.sp)
                            Text("Eu geralmente treino à tarde.", color = Muted)
                            OutlinedButton(onClick = { onSpeak("I usually work out in the afternoon.") }) {
                                Icon(Icons.Default.VolumeUp, null); Spacer(Modifier.width(8.dp)); Text("Listen to phrase")
                            }
                        }
                        Quiz("What does “work out” mean?", listOf("To sleep", "To exercise", "To study"), 1,
                            answer, { answer = it; feedback = "" }, feedback) { selected ->
                            feedback = if (selected == 1) { award("listenquiz", 10); "Correct! Work out means to exercise." }
                            else "Try again: work out means to exercise."
                        }
                        Button(onClick = { award("listen"); page = "Home" }, modifier = Modifier.fillMaxWidth()) { Text("Finish listening (+20 XP)") }
                    }
                    "Speak" -> {
                        Header("Speaking practice", "Answer in English. You can type or use your microphone.")
                        CardBlock {
                            Text("AI teacher", color = Purple, fontWeight = FontWeight.Bold)
                            Text("Hey Gustavo! What do you usually do after work or school?", fontSize = 18.sp)
                            Text("Try to answer with at least two sentences.", color = Muted)
                        }
                        OutlinedTextField(
                            value = typed, onValueChange = { typed = it }, modifier = Modifier.fillMaxWidth(),
                            label = { Text("Your answer in English") },
                            placeholder = { Text("I usually...") },
                            minLines = 3
                        )
                        Button(
                            onClick = {
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    listening = true
                                    startSpeechRecognition(context) { recognized = it; typed = it; listening = false }
                                } else permission.launch(Manifest.permission.RECORD_AUDIO)
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34304F))
                        ) {
                            Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp))
                            Text(if (listening) "Listening..." else "Speak with microphone")
                        }
                        if (recognized.isNotBlank()) Text("Recognized: $recognized", color = Color(0xFF9BE0B4))
                        Button(onClick = {
                            if (typed.isNotBlank()) {
                                val message = "Please correct my A1 English, explain my mistakes in Portuguese, and ask me a follow-up question. My answer: $typed"
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, message)
                                }
                                context.startActivity(Intent.createChooser(send, "Send answer to your AI English teacher"))
                                award("speak")
                            }
                        }, modifier = Modifier.fillMaxWidth(), enabled = typed.isNotBlank()) { Text("Send to AI teacher · +20 XP") }
                        Text("This opens Android's share menu. Choose ChatGPT if installed. AI correction requires an internet connection and ChatGPT.", color = Muted, fontSize = 12.sp)
                    }
                    "Words" -> {
                        Header("Vocabulary builder", "Useful expressions for your everyday life.")
                        val words = listOf(
                            Triple("usually", "geralmente", "I usually train after school."),
                            Triple("improve", "melhorar", "I want to improve my English."),
                            Triple("strength", "força", "I want to build strength."),
                            Triple("work out", "treinar / fazer exercício", "I work out three times a week."),
                            Triple("although", "embora", "Although I'm tired, I want to train."),
                            Triple("free time", "tempo livre", "I play games in my free time.")
                        )
                        words.forEach { (en, pt, example) ->
                            CardBlock {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(en, color = Purple, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                        Text(pt, color = Muted)
                                        Text(example, fontSize = 13.sp)
                                    }
                                    IconButton(onClick = { onSpeak("$en. $example") }) { Icon(Icons.Default.VolumeUp, null) }
                                }
                            }
                        }
                        Button(onClick = { award("words"); page = "Home" }, modifier = Modifier.fillMaxWidth()) { Text("Finish vocabulary (+20 XP)") }
                    }
                    else -> {
                        Header("Your progress", "Your learning progress is saved on this device.")
                        CardBlock {
                            Text("TOTAL EXPERIENCE", color = Muted, fontSize = 11.sp)
                            Text("$xp XP", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                            LinearProgressIndicator(progress = { (xp % 100) / 100f }, modifier = Modifier.fillMaxWidth())
                            Text("${100 - (xp % 100)} XP to the next 100 XP milestone", color = Muted, fontSize = 12.sp)
                        }
                        Text("Daily missions", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        listOf("listen" to "Listening", "speak" to "Speaking", "words" to "Vocabulary").forEach { (id, name) ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name)
                                Text(if (done.contains(id)) "Completed ✓" else "Pending", color = if (done.contains(id)) Color(0xFF76D9A0) else Muted)
                            }
                        }
                        OutlinedButton(onClick = {
                            xp = 0; done = emptySet()
                            prefs.edit().clear().apply()
                        }, modifier = Modifier.fillMaxWidth()) { Text("Reset demo progress") }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("ENGLISHUP · NEW LEVEL · VERSION 1.0", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp), content = content)
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column {
        Text(value, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun Header(title: String, subtitle: String) {
    Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Text(subtitle, color = Muted)
}

@Composable
private fun Example(english: String, portuguese: String, onSpeak: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(english, Modifier.weight(1f), fontSize = 18.sp, color = Color(0xFFC4B9FF), fontWeight = FontWeight.SemiBold)
            IconButton(onClick = { onSpeak(english) }) { Icon(Icons.Default.VolumeUp, null) }
        }
        Text(portuguese, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun Quiz(
    question: String, options: List<String>, correct: Int, answer: String,
    onAnswer: (String) -> Unit, feedback: String, onCheck: (Int) -> Unit
) {
    CardBlock {
        Text(question, fontWeight = FontWeight.Bold)
        options.forEachIndexed { index, option ->
            Row(
                Modifier.fillMaxWidth().clickable { onAnswer(index.toString()) }.padding(vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = answer == index.toString(), onClick = { onAnswer(index.toString()) })
                Text(option)
            }
        }
        Button(onClick = { answer.toIntOrNull()?.let(onCheck) }, enabled = answer.isNotBlank()) { Text("Check answer") }
        if (feedback.isNotBlank()) Text(feedback, color = if (answer.toIntOrNull() == correct) Color(0xFF8FE0AD) else Color(0xFFFFB4A9))
    }
}

private fun startSpeechRecognition(context: android.content.Context, onResult: (String) -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) return
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in English")
    }
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { recognizer.destroy() }
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            onResult(text); recognizer.destroy()
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    recognizer.startListening(intent)
}
